#include "ras.h"

// Rotationary Angle sensor reading states

typedef struct {
    Event *callback_event;      // the callback event for data processing
    uint32_t raw_data;          // the raw reading from the ADC connected to the sensor
    bool new_input;             // if any new data input is ready
} RotSensorState;
RotSensorState ras_sensor;


/*
 * Initialize ADC to use Tiva C's internal temperature sensor
 *
 * Resources: ADC0, sequence #0, special channel TS (temperature sensor)
 * Configurations: processor trigger, interrupt enabled, use step 0 only
 */

void RasInit() {

    ras_sensor.callback_event = NULL;
    ras_sensor.new_input = false;

    // Enable the ADC0 peripheral
    SysCtlPeripheralEnable(SYSCTL_PERIPH_ADC0);

    // Configure ADC0's sequencer #1
    ADCSequenceConfigure(ADC0_BASE, 1, ADC_TRIGGER_PROCESSOR, 0);

    // Configure step 0 of sequencer 1 to use RAS
    ADCSequenceStepConfigure(ADC0_BASE, 1, 0, ADC_CTL_CH7 | ADC_CTL_IE | ADC_CTL_END); // CHANGE TO CORRECT CHANNEL

    // Register the ISR
    ADCIntRegister(ADC0_BASE, 1, RasISR);

    ADCIntEnable(ADC0_BASE, 1);

    // Enable ADC0 sequencer 1
    ADCSequenceEnable(ADC0_BASE, 1);
}

void RasTriggerReading() {
    ADCProcessorTrigger(ADC0_BASE, 1);
}

bool RasDataReady() {
    return ras_sensor.new_input; // return new_input
}

float RasDataRead() {
    ras_sensor.new_input = false;
    return (ras_sensor.raw_data /  4096.0) * 180; // Convert ADC value to angle
}

void RasEventRegister(Event *event) {
    ras_sensor.callback_event = event;
}

void RasISR() {

    uint32_t ADCValue;
    ADCSequenceDataGet(ADC0_BASE, 1, &ADCValue);

    ras_sensor.raw_data = ADCValue;
    ras_sensor.new_input = true;

    // Schedule event for processing data
    EventSchedule(ras_sensor.callback_event, EventGetCurrentTime());

    ADCIntClear(ADC0_BASE, 1);
}

