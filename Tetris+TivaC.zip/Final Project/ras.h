#ifndef RAS_H_
#define RAS_H_

#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <inc/hw_memmap.h>
#include <inc/hw_ints.h>
#include <driverlib/sysctl.h>
#include <driverlib/interrupt.h>
#include <driverlib/adc.h>
#include "launchpad.h"

// Initialize ADC to use Tiva C's internal temperature sensor
void RasInit();

// Trigger temperature reading
void RasTriggerReading();

// Check if any new reading is ready (for I/O polling)
bool RasDataReady();

// Return temperature reading in Fahrenheit
float RasDataRead();

// Set callback event for temperature sensor ISR
void RasEventRegister(Event *event);

// The ISR function
void RasISR();

#endif /* RAS_H_ */

