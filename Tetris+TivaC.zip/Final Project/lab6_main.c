/*
 * Starter code for ECE 266 Lab 6, main.c, fall 2024
 *
 * Lab 6: Temperature reading and knob input (ADC)
 *
 * Created by Zhao Zhang
 */

#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include "launchpad.h"
#include "ras.h"
#include "driverlib/sysctl.h"
#include "driverlib/uart.h"
#include "driverlib/gpio.h"
#include "driverlib/pin_map.h"

// The events
Event ras_trigger_event;
Event ras_data_event;
Event check_push_button_event;

// Function to send strings via UART
void UARTSend(const char *str) {
    while (*str) {
        UARTCharPut(UART0_BASE, *str++); // Send each character via UART
    }
}

// Initializes UART
void InitUART(void) {
    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0); // Enable UART0
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA); // Enable GPIOA for UART pins

    GPIOPinConfigure(GPIO_PA0_U0RX); // RX Pin
    GPIOPinConfigure(GPIO_PA1_U0TX); // TX Pin
    GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);

    UARTConfigSetExpClk(UART0_BASE, SysCtlClockGet(), 115200,
                        (UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE | UART_CONFIG_PAR_NONE));
}

// Triggers ADC sampling for the RAS at 500 ms
void TriggerRotationReading(Event *event) {
    RasTriggerReading();
    EventSchedule(event, event->time + 500);
}

// Reads the rotation angle data from the ADC and processes it
void ProcessRotationReading(Event *event) {
    char buffer[50]; // Buffer to store formatted output
    float rot_D = RasDataRead();                 // Read RAS
    int angle_whole = (int)rot_D;                // Integer part
    int angle_dec = (int)((rot_D - angle_whole) * 10); // Decimal part

    // Format the output and send it via UART
    snprintf(buffer, sizeof(buffer), "Rotation Angle: %d.%d\r\n", angle_whole, angle_dec);
    UARTSend(buffer);
}

// Checks the buttons
void CheckPushButton(Event *event) {
    int code = PushButtonRead(); // Read the state of the push button
    switch (code) {
        case 1: // If SW1 is pushed
            UARTSend("Left\r\n"); // Send "Left" via UART
            break;
        case 2: // If SW2 is pushed
            UARTSend("Right\r\n"); // Send "Right" via UART
            break;
    }
}

// Main function: Initialize the system and run event scheduler loop
int main(void) {
    // Set clock to 40 MHz
    SysCtlClockSet(SYSCTL_SYSDIV_5 | SYSCTL_USE_PLL | SYSCTL_OSC_MAIN | SYSCTL_XTAL_16MHZ);

    // Initialize hardware components
    InitUART();       // Initialize UART
    LaunchPadInit();  // Initialize LaunchPad hardware
    RasInit();        // Initialize RAS sensor

    // Initialize events
    EventInit(&check_push_button_event, CheckPushButton);

    // Initialize and schedule timing events
    EventInit(&ras_trigger_event, TriggerRotationReading);
    EventSchedule(&ras_trigger_event, 100);

    // Initialize and register ISR events
    EventInit(&ras_data_event, ProcessRotationReading);
    RasEventRegister(&ras_data_event);

    PushButtonEventRegister(&check_push_button_event); // Register push button event

    UARTSend("Rotary Angle Sensor Processing\r\n");

    // Main loop
    while (true) {
        __asm("    wfi"); // Wait for interrupt to happen
        EventExecute();   // Execute scheduled events
    }
}
