import serial
import time

def read_tiva_data(port, baudrate=115200, log_file=None):
    try:
        # Open the serial port
        ser = serial.Serial(port, baudrate, timeout=1)
        print(f"Connected to {port} at {baudrate} baud.")
        print("Press Ctrl+C to stop.")
        
        # Open the log file if provided
        file = open(log_file, 'a') if log_file else None

        while True:
            # Read a line of data from the Tiva C
            data = ser.readline().decode('utf-8').strip()
            if data:
                # Print the data to the console
                print(f"Tiva C Data: {data}")

                # Log the data to a file if logging is enabled
                if file:
                    timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
                    file.write(f"{timestamp}: {data}\n")

    except serial.SerialException as e:
        print(f"Serial Error: {e}")
    except KeyboardInterrupt:
        print("\nStopping...")
    finally:
        # Clean up resources
        if file:
            file.close()
        ser.close()

if __name__ == "__main__":
   
    port = '/dev/cu.usbmodem0E239A881'  # Update with your Tiva C COM port
    baudrate = 115200
    log_file = None  

    read_tiva_data(port=port, baudrate=baudrate, log_file=log_file)
